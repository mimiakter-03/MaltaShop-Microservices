# MaltaShop: Order + Notification microservices prototype

Educational prototype for Unit 5, Service-Oriented Architecture and Microservices Fundamentals. **Not production ready.**

## Architecture

`POST /orders` -> Order service (own SQLite volume) -> RabbitMQ durable `order_placed` queue -> Notification worker (separate SQLite volume).

Order events contain an `order_id` and `correlation_id`. The notification consumer uses `INSERT OR IGNORE` on `order_id` to make duplicate delivery harmless. The order service records unpublished events for manual retry if RabbitMQ is temporarily unavailable. This is **not a fully atomic transactional outbox**: there remains a failure window between broker confirmation and marking an event published. The Payment/Inventory saga is a proposed design, not implemented in this small prototype.

## Prerequisites

Docker Desktop with Compose, Git and (optional) Python 3.12.

## Run

1. Copy `.env.example` to `.env` and change `DEMO_ADMIN_KEY`.
2. From this directory run: `docker compose up --build`
3. In another terminal (PowerShell):

```powershell
Invoke-RestMethod -Method Post -Uri http://localhost:5000/orders -ContentType 'application/json' -Body '{"product":"Laptop","quantity":1}' -Headers @{'X-Correlation-ID'='demo-001'}
```

Or in Bash:

```bash
curl -i -X POST http://localhost:5000/orders -H 'Content-Type: application/json' -H 'X-Correlation-ID: demo-001' -d '{"product":"Laptop","quantity":1}'
```

Expected HTTP status: `202 Accepted`, JSON with order ID, status, correlation ID and `event_published`. The event flag may be false if RabbitMQ is temporarily unavailable. To retry pending events:

```bash
curl -X POST http://localhost:5000/admin/retry-events -H 'X-Demo-Admin-Key: replace-with-a-strong-random-value'
```

Check consumer logs:

```bash
docker compose logs notification
```

Check both services for the same `correlation_id`:

```bash
docker compose logs order notification
```

RabbitMQ admin interface: http://localhost:15672 (default guest/guest; local demonstration only).

Stop: `docker compose down`. To delete all stored test data: `docker compose down -v`.

## Tests

```bash
python -m pip install -r order-service/requirements.txt
python -m unittest discover -s tests -v
```

GitHub Actions workflow at `.github/workflows/ci.yml` runs syntax checks, unit and contract tests, builds both images, and validates Compose. A passing run must be obtained on **your own** GitHub repository and captured as evidence.

## Environment variables

| Variable | Service | Purpose |
|---|---|---|
| `ORDER_DB` | Order | SQLite database path, defaults `/data/orders.db` |
| `NOTIFICATION_DB` | Notification | SQLite database path, defaults `/data/notifications.db` |
| `RABBITMQ_HOST` | Both | Broker hostname, defaults `rabbitmq` |
| `DEMO_ADMIN_KEY` | Order | Demo-only retry endpoint secret; change in `.env` |

## Scope and limitations

- No real Payment or Inventory services, payment card processing, login, partner access control, or AI recommendation engine.
- No full production-grade outbox, dead-letter queue, automatic retry scheduler, metrics, distributed traces, or load testing.
- SQLite per service is suitable for a small laptop demonstration, not the proposed high-availability production system.
- HTTP service is local-only, and RabbitMQ management uses demo credentials. Do not deploy publicly as-is.
- Production would add PostgreSQL, secure secrets, TLS, API gateway, robust outbox, observability, and orchestration.

## Required evidence for assignment

Capture real screenshots after running the software: (1) request and HTTP response, (2) notification consumer log, (3) order and notification logs with matching correlation ID, (4) green GitHub Actions run. Add them to `evidence/`. Record the real repository URL in the report appendix. Make your own commits over time and be ready to explain the design.
